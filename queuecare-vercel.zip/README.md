# QueueCare - Hospital Queue (Beat the Wait)

Next.js 16 app (JavaScript). Upload this folder's contents to the ROOT of a GitHub repo and import it in Vercel.

- Patients: / (live queue, book token, track token)
- Hospital staff: /staff  (default PIN 1234 - set STAFF_PIN in Vercel to change it)

Optional (keeps data permanently): add an Upstash Redis database from the Vercel Storage / Marketplace tab and connect it to the project.
The app reads UPSTASH_REDIS_REST_URL + UPSTASH_REDIS_REST_TOKEN (or KV_REST_API_URL + KV_REST_API_TOKEN). Without it, data lives in server memory (demo mode).
