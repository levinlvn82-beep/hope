import { NextResponse } from 'next/server';
import { loadState, saveState, isPersistent } from '../../../lib/store';
import { addToken, waitingFor, servingFor, seedState, publicState, staffState } from '../../../lib/queue';

export const dynamic = 'force-dynamic';

const STAFF_PIN = process.env.STAFF_PIN || '1234';
const STAFF_ACTIONS = new Set(['callNext', 'complete', 'skip', 'setPriority', 'setDoctorStatus', 'setAvg', 'reset']);

const json = (body, status = 200) =>
  NextResponse.json(body, { status, headers: { 'Cache-Control': 'no-store' } });
const fail = (error, status = 400) => json({ ok: false, error }, status);
const clean = (v, max) => String(v === undefined || v === null ? '' : v).trim().slice(0, max);
const digits = (v) => String(v === undefined || v === null ? '' : v).replace(/\D/g, '');
const isStaff = (request) => request.headers.get('x-staff-pin') === STAFF_PIN;

export async function GET(request) {
  try {
    const state = await loadState();
    const staff = isStaff(request);
    return json({
      ok: true,
      staff,
      persistent: isPersistent,
      now: Date.now(),
      state: staff ? staffState(state) : publicState(state),
    });
  } catch (e) {
    return fail('Could not load queue data.', 500);
  }
}

export async function POST(request) {
  let body;
  try {
    body = await request.json();
  } catch (e) {
    return fail('Invalid request.');
  }
  const staff = isStaff(request);
  const action = body && body.action;
  if (STAFF_ACTIONS.has(action) && !staff) return fail('Staff PIN required.', 401);

  try {
    const state = await loadState();
    const now = Date.now();
    const doctorOf = (id) => state.doctors.find((d) => d.id === id);
    const tokenOf = (id) => state.tokens.find((t) => t.id === id);

    if (action === 'book') {
      const doctor = doctorOf(body.doctorId);
      if (!doctor) return fail('Please choose a doctor.');
      if (doctor.status === 'off') return fail(doctor.name + ' is off duty right now.');
      const name = clean(body.name, 60);
      if (name.length < 2) return fail('Please enter the patient name.');
      const phone = digits(body.phone);
      if (!staff && (phone.length < 10 || phone.length > 13)) return fail('Please enter a valid 10-digit phone number.');
      if (phone) {
        const dup = state.tokens.find(
          (t) => t.doctorId === doctor.id && t.phone === phone && t.name.toLowerCase() === name.toLowerCase() &&
            (t.status === 'waiting' || t.status === 'serving')
        );
        if (dup) return fail('This patient already has an active token (' + dup.code + ') with this doctor.');
      }
      let age = null;
      if (body.age !== '' && body.age !== undefined && body.age !== null) {
        age = Number(body.age);
        if (!Number.isFinite(age) || age < 0 || age > 120) return fail('Please enter a valid age.');
      }
      const token = addToken(state, doctor.id, {
        name,
        phone,
        age,
        reason: clean(body.reason, 200),
        priority: staff && body.priority === 'emergency' ? 'emergency' : 'normal',
        emergencyRequested: !!body.emergencyRequested,
      });
      await saveState(state);
      return json({ ok: true, token: { id: token.id, code: token.code, doctorId: token.doctorId, number: token.number }, cancelKey: token.cancelKey });
    }

    if (action === 'cancel') {
      const token = tokenOf(body.tokenId);
      if (!token) return fail('Token not found.', 404);
      if (!staff && token.cancelKey !== body.cancelKey) return fail('You can only cancel a token booked on this device.', 403);
      if (token.status !== 'waiting') return fail('Only waiting tokens can be cancelled.');
      token.status = 'cancelled';
      token.doneAt = now;
      await saveState(state);
      return json({ ok: true });
    }

    if (action === 'callNext') {
      const doctor = doctorOf(body.doctorId);
      if (!doctor) return fail('Doctor not found.', 404);
      const current = servingFor(state, doctor.id);
      if (current) {
        current.status = 'done';
        current.doneAt = now;
      }
      const next = waitingFor(state, doctor.id)[0];
      if (next) {
        next.status = 'serving';
        next.calledAt = now;
        next.emergencyRequested = false;
        doctor.status = 'available';
      }
      await saveState(state);
      return json({ ok: true, called: next ? next.code : null });
    }

    if (action === 'complete') {
      const current = servingFor(state, body.doctorId);
      if (!current) return fail('No patient is being served.');
      current.status = 'done';
      current.doneAt = now;
      await saveState(state);
      return json({ ok: true });
    }

    if (action === 'skip') {
      const token = tokenOf(body.tokenId);
      if (!token || (token.status !== 'waiting' && token.status !== 'serving')) return fail('Token not found.', 404);
      token.status = 'skipped';
      token.doneAt = now;
      await saveState(state);
      return json({ ok: true });
    }

    if (action === 'setPriority') {
      const token = tokenOf(body.tokenId);
      if (!token || token.status !== 'waiting') return fail('Only waiting tokens can change priority.');
      if (body.priority === 'emergency') {
        token.priority = 'emergency';
        token.prioritySince = now;
        token.emergencyRequested = false;
      } else {
        token.priority = 'normal';
        token.prioritySince = null;
        token.emergencyRequested = false;
      }
      await saveState(state);
      return json({ ok: true });
    }

    if (action === 'setDoctorStatus') {
      const doctor = doctorOf(body.doctorId);
      if (!doctor) return fail('Doctor not found.', 404);
      if (!['available', 'break', 'off'].includes(body.status)) return fail('Invalid status.');
      doctor.status = body.status;
      await saveState(state);
      return json({ ok: true });
    }

    if (action === 'setAvg') {
      const doctor = doctorOf(body.doctorId);
      const minutes = Math.round(Number(body.minutes));
      if (!doctor) return fail('Doctor not found.', 404);
      if (!Number.isFinite(minutes) || minutes < 1 || minutes > 90) return fail('Enter minutes between 1 and 90.');
      doctor.avgMinutes = minutes;
      await saveState(state);
      return json({ ok: true });
    }

    if (action === 'reset') {
      await saveState(seedState());
      return json({ ok: true });
    }

    return fail('Unknown action.');
  } catch (e) {
    return fail('Something went wrong. Please try again.', 500);
  }
}
