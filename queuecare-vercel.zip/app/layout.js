import './globals.css';
import Link from 'next/link';

export const metadata = {
  title: 'QueueCare - Beat the Wait',
  description: 'Book a hospital token online, track the live queue, see doctor availability and your estimated waiting time.',
};

export const viewport = {
  width: 'device-width',
  initialScale: 1,
  themeColor: '#0f766e',
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>
        <header className="site-header">
          <div className="container header-in">
            <Link href="/" className="brand"><span className="logo">+</span> QueueCare</Link>
            <nav className="nav">
              <Link href="/#live">Live queue</Link>
              <Link href="/#book">Book token</Link>
              <Link href="/#track">Track token</Link>
              <Link href="/staff" className="nav-staff">Staff</Link>
            </nav>
          </div>
        </header>
        {children}
        <footer className="site-footer">
          <div className="container">
            <p>QueueCare - Hospital Queue 404. In a life-threatening emergency, go straight to the Emergency desk or call 108 / 112.</p>
          </div>
        </footer>
      </body>
    </html>
  );
}
