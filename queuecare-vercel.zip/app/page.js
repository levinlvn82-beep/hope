'use client';

import { useState } from 'react';
import { useQueue } from '../components/useQueue';
import DoctorBoard from '../components/DoctorBoard';
import BookingForm from '../components/BookingForm';
import TrackToken from '../components/TrackToken';
import { doctorStatus } from '../lib/queue';

export default function Home() {
  const { data, error, refresh } = useQueue();
  const [preset, setPreset] = useState('');
  const state = data ? data.state : null;

  const waiting = state ? state.tokens.filter((t) => t.status === 'waiting') : [];
  const priority = waiting.filter((t) => t.priority === 'emergency').length;
  const onDuty = state
    ? state.doctors.filter((d) => {
        const k = doctorStatus(state, d).key;
        return k === 'available' || k === 'busy';
      }).length
    : 0;

  return (
    <main>
      <section className="hero">
        <div className="container">
          <p className="eyebrow">Hospital Queue 404</p>
          <h1>Beat the wait. Know your turn before you reach the hospital.</h1>
          <p className="lead">Book a token from home, watch the queue move live, and see when your doctor will be ready.</p>
          <p className="tamil">காத்திருக்கும் நேரத்தைக் குறைப்போம்</p>
          <div className="hero-actions">
            <a className="btn btn-primary btn-lg" href="#book">Book a token</a>
            <a className="btn btn-light btn-lg" href="#track">Track my token</a>
          </div>
          <div className="stats">
            <div className="stat"><strong>{state ? waiting.length : '-'}</strong><span>Waiting now</span></div>
            <div className="stat"><strong>{state ? onDuty : '-'}</strong><span>Doctors on duty</span></div>
            <div className="stat"><strong>{state ? priority : '-'}</strong><span>Emergency priority</span></div>
          </div>
        </div>
      </section>

      {error && !data && <div className="container"><p className="banner error-banner">Cannot reach the server right now. Retrying...</p></div>}
      {data && !data.persistent && (
        <div className="container"><p className="banner">Demo mode: queue data is stored in server memory and may reset.</p></div>
      )}

      <section id="live" className="section">
        <div className="container">
          <h2>Live queue &amp; doctor availability</h2>
          <p className="muted">Updates automatically every few seconds. Emergency cases are identified by hospital staff and seen first.</p>
          {state ? <DoctorBoard state={state} /> : <p className="muted">Loading the live queue...</p>}
        </div>
      </section>

      <section id="book" className="section alt">
        <div className="container narrow-box">
          <h2>Book your token online</h2>
          <p className="muted">Pick a doctor, see the expected wait, and get your token number instantly.</p>
          {state ? <BookingForm state={state} onBooked={setPreset} refresh={refresh} /> : <p className="muted">Loading...</p>}
        </div>
      </section>

      <section id="track" className="section">
        <div className="container narrow-box">
          <h2>Track your token</h2>
          <p className="muted">See what number is being served now and how long you still need to wait.</p>
          {state ? <TrackToken state={state} preset={preset} refresh={refresh} /> : <p className="muted">Loading...</p>}
        </div>
      </section>
    </main>
  );
}
