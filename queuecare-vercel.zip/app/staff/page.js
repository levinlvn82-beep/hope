'use client';

import { useEffect, useState } from 'react';
import { useQueue } from '../../components/useQueue';
import StaffPanel from '../../components/StaffPanel';

const PIN_KEY = 'queuecare:pin';

export default function StaffPage() {
  const [pin, setPin] = useState('');
  const [input, setInput] = useState('');
  const { data, error, refresh } = useQueue(pin);

  useEffect(() => {
    try {
      const saved = sessionStorage.getItem(PIN_KEY);
      if (saved) setPin(saved);
    } catch (e) {
      /* ignore */
    }
  }, []);

  const authed = !!(data && data.staff);
  const wrongPin = !!(pin && data && !data.staff);

  useEffect(() => {
    if (wrongPin) {
      try { sessionStorage.removeItem(PIN_KEY); } catch (e) { /* ignore */ }
    }
  }, [wrongPin]);

  function login(e) {
    e.preventDefault();
    try { sessionStorage.setItem(PIN_KEY, input); } catch (err) { /* ignore */ }
    setPin(input);
  }

  function logout() {
    try { sessionStorage.removeItem(PIN_KEY); } catch (e) { /* ignore */ }
    setPin('');
    setInput('');
  }

  return (
    <main className="section">
      <div className="container">
        <div className="staff-head">
          <div>
            <p className="eyebrow dark">Hospital staff</p>
            <h1 className="h1-sm">Queue control desk</h1>
          </div>
          {authed && <button className="btn btn-ghost" onClick={logout}>Log out</button>}
        </div>

        {error && !data && <p className="banner error-banner">Cannot reach the server right now. Retrying...</p>}

        {!authed ? (
          <form className="card form login" onSubmit={login}>
            <div className="field">
              <label htmlFor="pin">Staff PIN</label>
              <input id="pin" type="password" value={input} onChange={(e) => setInput(e.target.value)} placeholder="Enter PIN" autoComplete="off" required />
            </div>
            {wrongPin && <p className="error">Incorrect PIN. Please try again.</p>}
            <button className="btn btn-primary">Open staff desk</button>
          </form>
        ) : (
          <StaffPanel state={data.state} pin={pin} refresh={refresh} persistent={data.persistent} />
        )}
      </div>
    </main>
  );
}
