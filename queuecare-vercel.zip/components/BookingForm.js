'use client';

import { useState } from 'react';
import { postAction } from './useQueue';
import { saveMyToken } from '../lib/client';
import { doctorStatus, joinEstimate, formatMinutes } from '../lib/queue';

const EMPTY = { doctorId: '', name: '', phone: '', age: '', reason: '', emergencyRequested: false };

export default function BookingForm({ state, onBooked, refresh }) {
  const [form, setForm] = useState(EMPTY);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [done, setDone] = useState(null);

  const doctorId = form.doctorId || (state.doctors[0] ? state.doctors[0].id : '');
  const doctor = state.doctors.find((d) => d.id === doctorId);
  const est = doctor ? joinEstimate(state, doctor) : null;

  const set = (key) => (e) => {
    const value = e.target.type === 'checkbox' ? e.target.checked : e.target.value;
    setForm((f) => ({ ...f, [key]: value }));
  };

  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      const res = await postAction({ action: 'book', ...form, doctorId });
      saveMyToken({ id: res.token.id, code: res.token.code, cancelKey: res.cancelKey });
      setDone({ code: res.token.code, doctorName: doctor ? doctor.name : '', requested: form.emergencyRequested });
      setForm(EMPTY);
      onBooked(res.token.code);
      await refresh();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  if (done) {
    return (
      <div className="card token-done">
        <p className="label">Your token</p>
        <div className="token-code">{done.code}</div>
        <p>Booked with <strong>{done.doctorName}</strong>. Keep this number - you can track it live below.</p>
        {done.requested && (
          <p className="note">Emergency review requested. Please tell the hospital desk when you arrive so staff can check you.</p>
        )}
        <button className="btn btn-primary" onClick={() => setDone(null)}>Book another token</button>
      </div>
    );
  }

  return (
    <form className="card form" onSubmit={submit}>
      <div className="field">
        <label htmlFor="doctor">Doctor</label>
        <select id="doctor" value={doctorId} onChange={set('doctorId')}>
          {state.doctors.map((d) => {
            const st = doctorStatus(state, d);
            const e2 = joinEstimate(state, d);
            return (
              <option key={d.id} value={d.id} disabled={st.key === 'off'}>
                {d.name} - {d.dept} ({st.key === 'off' ? 'off duty' : e2.ahead + ' waiting, about ' + formatMinutes(e2.minutes)})
              </option>
            );
          })}
        </select>
        {est && doctor && doctor.status !== 'off' && (
          <p className="hint">If you book now: {est.ahead} patient{est.ahead === 1 ? '' : 's'} ahead, estimated wait about {formatMinutes(est.minutes)}.</p>
        )}
      </div>

      <div className="row">
        <div className="field">
          <label htmlFor="name">Patient name</label>
          <input id="name" value={form.name} onChange={set('name')} placeholder="Full name" required maxLength={60} />
        </div>
        <div className="field narrow">
          <label htmlFor="age">Age</label>
          <input id="age" type="number" min="0" max="120" value={form.age} onChange={set('age')} placeholder="Years" />
        </div>
      </div>

      <div className="field">
        <label htmlFor="phone">Phone number</label>
        <input id="phone" type="tel" inputMode="numeric" value={form.phone} onChange={set('phone')} placeholder="10-digit mobile number" required />
      </div>

      <div className="field">
        <label htmlFor="reason">Reason for visit (optional)</label>
        <textarea id="reason" rows={2} value={form.reason} onChange={set('reason')} placeholder="Fever, follow-up, chest pain..." maxLength={200} />
      </div>

      <label className="check">
        <input type="checkbox" checked={form.emergencyRequested} onChange={set('emergencyRequested')} />
        <span>
          <strong>This may be an emergency</strong> - ask hospital staff to check me for priority.
          <small>Staff confirm priority at the desk. For a life-threatening emergency, go straight to the Emergency desk or call 108 / 112.</small>
        </span>
      </label>

      {error && <p className="error">{error}</p>}
      <button className="btn btn-primary btn-lg" disabled={busy}>{busy ? 'Booking...' : 'Book my token'}</button>
    </form>
  );
}
