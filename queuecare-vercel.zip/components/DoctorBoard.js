'use client';

import { StatusBadge } from './ui';
import { doctorStatus, servingFor, waitingFor, joinEstimate, formatMinutes } from '../lib/queue';

function DoctorCard({ state, doctor }) {
  const st = doctorStatus(state, doctor);
  const serving = servingFor(state, doctor.id);
  const waiting = waitingFor(state, doctor.id);
  const est = joinEstimate(state, doctor);
  const shown = waiting.slice(0, 8);

  return (
    <article className="card doc-card">
      <div className="doc-head">
        <div>
          <h3>{doctor.name}</h3>
          <p className="muted">{doctor.dept} &middot; {doctor.room}</p>
        </div>
        <StatusBadge kind={st.key} label={st.label} />
      </div>

      <div className="doc-stats">
        <div>
          <span className="label">Now serving</span>
          <strong className="big">{serving ? serving.code : '-'}</strong>
        </div>
        <div>
          <span className="label">Waiting</span>
          <strong className="big">{waiting.length}</strong>
        </div>
        <div>
          <span className="label">New token wait</span>
          <strong className="big small">{st.key === 'off' ? '-' : formatMinutes(est.minutes)}</strong>
        </div>
      </div>

      {waiting.length > 0 ? (
        <>
          <p className="label">Next in line</p>
          <div className="chips">
            {shown.map((t) => (
              <span key={t.id} className={'chip' + (t.priority === 'emergency' ? ' chip-emergency' : '')}>
                {t.priority === 'emergency' ? 'Priority ' : ''}{t.code}
              </span>
            ))}
            {waiting.length > shown.length && <span className="chip chip-more">+{waiting.length - shown.length} more</span>}
          </div>
        </>
      ) : (
        <p className="muted">No one is waiting right now.</p>
      )}

      {st.key === 'break' && <p className="note">The doctor is on a short break. Waiting times may be longer than shown.</p>}
      {st.key === 'off' && <p className="note">The doctor is not available right now.</p>}
    </article>
  );
}

export default function DoctorBoard({ state }) {
  return (
    <div className="grid doctors">
      {state.doctors.map((doc) => (
        <DoctorCard key={doc.id} state={state} doctor={doc} />
      ))}
    </div>
  );
}
