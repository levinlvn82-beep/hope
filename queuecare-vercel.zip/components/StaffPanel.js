'use client';

import { useState } from 'react';
import { postAction } from './useQueue';
import { StatusBadge } from './ui';
import { doctorStatus, servingFor, waitingFor } from '../lib/queue';

function minutesAgo(ts) {
  const m = Math.max(0, Math.round((Date.now() - ts) / 60000));
  return m < 1 ? 'just now' : m + ' min ago';
}

function DoctorDesk({ state, doctor, run, busy }) {
  const st = doctorStatus(state, doctor);
  const serving = servingFor(state, doctor.id);
  const waiting = waitingFor(state, doctor.id);

  return (
    <section className="card desk">
      <div className="doc-head">
        <div>
          <h3>{doctor.name}</h3>
          <p className="muted">{doctor.dept} &middot; {doctor.room}</p>
        </div>
        <StatusBadge kind={st.key} label={st.label} />
      </div>

      <div className="desk-controls">
        <label className="inline">
          Status
          <select value={doctor.status} onChange={(e) => run({ action: 'setDoctorStatus', doctorId: doctor.id, status: e.target.value })}>
            <option value="available">Available</option>
            <option value="break">On break</option>
            <option value="off">Off duty</option>
          </select>
        </label>
        <label className="inline">
          Minutes per patient
          <input
            type="number" min="1" max="90" key={doctor.avgMinutes} defaultValue={doctor.avgMinutes}
            onBlur={(e) => { if (Number(e.target.value) !== doctor.avgMinutes) run({ action: 'setAvg', doctorId: doctor.id, minutes: e.target.value }); }}
          />
        </label>
      </div>

      <div className="serving-box">
        <div>
          <span className="label">Now serving</span>
          {serving ? (
            <p><strong className="big">{serving.code}</strong> {serving.name}{serving.age !== null ? ', ' + serving.age : ''}
              {serving.reason ? <span className="muted"> - {serving.reason}</span> : null}</p>
          ) : (
            <p className="muted">No patient inside.</p>
          )}
        </div>
        <div className="btn-row">
          <button className="btn btn-primary" disabled={busy || waiting.length + (serving ? 1 : 0) === 0} onClick={() => run({ action: 'callNext', doctorId: doctor.id })}>
            {serving ? 'Finish and call next' : 'Call next'}
          </button>
          {serving && (
            <>
              <button className="btn btn-ghost" disabled={busy} onClick={() => run({ action: 'complete', doctorId: doctor.id })}>Finish</button>
              <button className="btn btn-ghost" disabled={busy} onClick={() => run({ action: 'skip', tokenId: serving.id })}>No-show</button>
            </>
          )}
        </div>
      </div>

      <p className="label">Waiting ({waiting.length})</p>
      {waiting.length === 0 ? (
        <p className="muted">Queue is empty.</p>
      ) : (
        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr><th>Token</th><th>Patient</th><th>Reason</th><th>Booked</th><th>Priority</th><th></th></tr>
            </thead>
            <tbody>
              {waiting.map((t) => (
                <tr key={t.id} className={t.priority === 'emergency' ? 'row-emergency' : t.emergencyRequested ? 'row-request' : ''}>
                  <td><strong>{t.code}</strong></td>
                  <td>{t.name}{t.age !== null ? ', ' + t.age : ''}<div className="muted tiny">{t.phone}</div></td>
                  <td>{t.reason || '-'}</td>
                  <td>{minutesAgo(t.createdAt)}</td>
                  <td>
                    {t.priority === 'emergency' && <StatusBadge kind="emergency" label="Emergency" />}
                    {t.priority !== 'emergency' && t.emergencyRequested && <StatusBadge kind="warn" label="Asked for priority" />}
                    {t.priority !== 'emergency' && !t.emergencyRequested && <span className="muted">Normal</span>}
                  </td>
                  <td className="actions">
                    {t.priority === 'emergency' ? (
                      <button className="btn btn-sm btn-ghost" disabled={busy} onClick={() => run({ action: 'setPriority', tokenId: t.id, priority: 'normal' })}>Remove priority</button>
                    ) : (
                      <button className="btn btn-sm btn-danger" disabled={busy} onClick={() => run({ action: 'setPriority', tokenId: t.id, priority: 'emergency' })}>
                        {t.emergencyRequested ? 'Confirm emergency' : 'Mark emergency'}
                      </button>
                    )}
                    <button className="btn btn-sm btn-ghost" disabled={busy} onClick={() => run({ action: 'skip', tokenId: t.id })}>Remove</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}

export default function StaffPanel({ state, pin, refresh, persistent }) {
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState('');
  const [walk, setWalk] = useState({ doctorId: '', name: '', age: '', phone: '', reason: '', emergency: false });

  async function run(body) {
    setBusy(true);
    setMsg('');
    try {
      const res = await postAction(body, pin);
      if (body.action === 'callNext') setMsg(res.called ? 'Now calling ' + res.called : 'Queue is empty.');
      await refresh();
    } catch (err) {
      setMsg(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function addWalkIn(e) {
    e.preventDefault();
    const doctorId = walk.doctorId || state.doctors[0].id;
    setBusy(true);
    setMsg('');
    try {
      const res = await postAction({
        action: 'book', doctorId, name: walk.name, age: walk.age, phone: walk.phone,
        reason: walk.reason, priority: walk.emergency ? 'emergency' : 'normal',
      }, pin);
      setMsg('Added ' + res.token.code + (walk.emergency ? ' as an emergency.' : '.'));
      setWalk({ doctorId, name: '', age: '', phone: '', reason: '', emergency: false });
      await refresh();
    } catch (err) {
      setMsg(err.message);
    } finally {
      setBusy(false);
    }
  }

  const waitingAll = state.tokens.filter((t) => t.status === 'waiting');
  const emergencies = waitingAll.filter((t) => t.priority === 'emergency');
  const requests = waitingAll.filter((t) => t.priority !== 'emergency' && t.emergencyRequested);
  const doneCount = state.tokens.filter((t) => t.status === 'done').length;
  const docName = (id) => state.doctors.find((d) => d.id === id).name;

  return (
    <>
      {!persistent && (
        <p className="banner">
          Demo mode: data is kept in server memory and can reset. To keep it permanently, connect an Upstash Redis database in Vercel (see README).
        </p>
      )}

      <div className="stats">
        <div className="stat"><strong>{waitingAll.length}</strong><span>Waiting</span></div>
        <div className="stat"><strong>{emergencies.length}</strong><span>Emergency priority</span></div>
        <div className="stat"><strong>{requests.length}</strong><span>To verify</span></div>
        <div className="stat"><strong>{doneCount}</strong><span>Seen</span></div>
      </div>

      {msg && <p className="toast">{msg}</p>}

      {requests.length > 0 && (
        <section className="card alert-card">
          <h3>Patients asking for emergency priority</h3>
          <p className="muted">Check the patient, then confirm. Confirmed emergencies jump to the front of that doctor's queue.</p>
          <ul className="req-list">
            {requests.map((t) => (
              <li key={t.id}>
                <span><strong>{t.code}</strong> {t.name}{t.age !== null ? ', ' + t.age : ''} &middot; {docName(t.doctorId)}{t.reason ? ' - ' + t.reason : ''}</span>
                <span className="btn-row">
                  <button className="btn btn-sm btn-danger" disabled={busy} onClick={() => run({ action: 'setPriority', tokenId: t.id, priority: 'emergency' })}>Confirm emergency</button>
                  <button className="btn btn-sm btn-ghost" disabled={busy} onClick={() => run({ action: 'setPriority', tokenId: t.id, priority: 'normal' })}>Not urgent</button>
                </span>
              </li>
            ))}
          </ul>
        </section>
      )}

      <h2 className="sub">Doctor desks</h2>
      <div className="grid desks">
        {state.doctors.map((d) => (
          <DoctorDesk key={d.id} state={state} doctor={d} run={run} busy={busy} />
        ))}
      </div>

      <h2 className="sub">Add a walk-in or emergency patient</h2>
      <form className="card form" onSubmit={addWalkIn}>
        <div className="row">
          <div className="field">
            <label htmlFor="wdoc">Doctor</label>
            <select id="wdoc" value={walk.doctorId || state.doctors[0].id} onChange={(e) => setWalk({ ...walk, doctorId: e.target.value })}>
              {state.doctors.map((d) => <option key={d.id} value={d.id}>{d.name} - {d.dept}</option>)}
            </select>
          </div>
          <div className="field">
            <label htmlFor="wname">Patient name</label>
            <input id="wname" value={walk.name} onChange={(e) => setWalk({ ...walk, name: e.target.value })} required maxLength={60} />
          </div>
        </div>
        <div className="row">
          <div className="field narrow">
            <label htmlFor="wage">Age</label>
            <input id="wage" type="number" min="0" max="120" value={walk.age} onChange={(e) => setWalk({ ...walk, age: e.target.value })} />
          </div>
          <div className="field">
            <label htmlFor="wphone">Phone (optional)</label>
            <input id="wphone" type="tel" value={walk.phone} onChange={(e) => setWalk({ ...walk, phone: e.target.value })} />
          </div>
          <div className="field">
            <label htmlFor="wreason">Reason</label>
            <input id="wreason" value={walk.reason} onChange={(e) => setWalk({ ...walk, reason: e.target.value })} maxLength={200} />
          </div>
        </div>
        <label className="check">
          <input type="checkbox" checked={walk.emergency} onChange={(e) => setWalk({ ...walk, emergency: e.target.checked })} />
          <span><strong>Emergency</strong> - put at the front of the queue</span>
        </label>
        <button className="btn btn-primary" disabled={busy}>Add to queue</button>
      </form>

      <div className="reset-row">
        <button className="btn btn-ghost" disabled={busy} onClick={() => { if (window.confirm('Reset all queue data to the demo sample?')) run({ action: 'reset' }); }}>
          Reset demo data
        </button>
      </div>
    </>
  );
}
