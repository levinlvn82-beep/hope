'use client';

import { useEffect, useState } from 'react';
import { postAction } from './useQueue';
import { loadMyTokens } from '../lib/client';
import { StatusBadge } from './ui';
import {
  doctorStatus, servingFor, estimateForToken, normalizeCode, formatMinutes, clockAfter,
} from '../lib/queue';

export default function TrackToken({ state, preset, refresh }) {
  const [query, setQuery] = useState('');
  const [mine, setMine] = useState([]);
  const [msg, setMsg] = useState('');

  useEffect(() => {
    const list = loadMyTokens();
    setMine(list);
    if (list[0]) setQuery(list[0].code);
  }, []);

  useEffect(() => {
    if (preset) {
      setQuery(preset);
      setMine(loadMyTokens());
    }
  }, [preset]);

  const code = normalizeCode(query);
  const token = code ? state.tokens.find((t) => t.code === code) : null;
  const doctor = token ? state.doctors.find((d) => d.id === token.doctorId) : null;
  const owned = token ? mine.find((m) => m.id === token.id) : null;

  async function cancel() {
    if (!window.confirm('Cancel token ' + token.code + '?')) return;
    try {
      await postAction({ action: 'cancel', tokenId: token.id, cancelKey: owned.cancelKey });
      setMsg('Token cancelled.');
      await refresh();
    } catch (err) {
      setMsg(err.message);
    }
  }

  let body = null;
  if (query && !code) {
    body = <p className="muted">Enter a token like G-012.</p>;
  } else if (code && !token) {
    body = <p className="muted">No active token found for {code}. Finished tokens disappear after 12 hours.</p>;
  } else if (token && doctor) {
    const serving = servingFor(state, doctor.id);
    const st = doctorStatus(state, doctor);
    if (token.status === 'waiting') {
      const est = estimateForToken(state, token);
      body = (
        <div className="track-result">
          <div className="track-top">
            <div>
              <p className="label">Token</p>
              <div className="token-code sm">{token.code}</div>
            </div>
            <div className="right">
              {token.priority === 'emergency' && <StatusBadge kind="emergency" label="Priority" />}
              <StatusBadge kind={st.key} label={'Doctor: ' + st.label} />
            </div>
          </div>
          <p>{doctor.name} &middot; {doctor.dept} &middot; {doctor.room}</p>
          <div className="doc-stats">
            <div><span className="label">Now serving</span><strong className="big">{serving ? serving.code : '-'}</strong></div>
            <div><span className="label">People ahead</span><strong className="big">{est.ahead}</strong></div>
            <div>
              <span className="label">Estimated wait</span>
              <strong className="big small">{est.ahead === 0 && !serving ? 'You are next' : formatMinutes(est.minutes)}</strong>
            </div>
          </div>
          {est.minutes > 0 && <p className="hint">Expected around {clockAfter(est.minutes)}. This updates live as the queue moves.</p>}
          {est.ahead <= 2 && <p className="note ok">Almost your turn - please be near {doctor.room}.</p>}
          {st.key === 'break' && <p className="note">The doctor is on a break, so your wait may be longer.</p>}
          {st.key === 'off' && <p className="note">The doctor is off duty. Please ask the front desk.</p>}
          {token.priority !== 'emergency' && (
            <p className="hint">Emergency cases are seen first, so your time can shift slightly.</p>
          )}
          {owned && <button className="btn btn-ghost" onClick={cancel}>Cancel this token</button>}
        </div>
      );
    } else if (token.status === 'serving') {
      body = (
        <div className="track-result">
          <div className="token-code sm">{token.code}</div>
          <p className="note ok"><strong>It is your turn.</strong> Please go to {doctor.room} now.</p>
        </div>
      );
    } else {
      const text = {
        done: 'Consultation completed.',
        skipped: 'This token was marked as missed. Please contact the front desk.',
        cancelled: 'This token was cancelled.',
      }[token.status];
      body = (
        <div className="track-result">
          <div className="token-code sm">{token.code}</div>
          <p className="muted">{text}</p>
        </div>
      );
    }
  }

  return (
    <div className="card">
      <div className="field">
        <label htmlFor="track">Token number</label>
        <input id="track" value={query} onChange={(e) => { setQuery(e.target.value); setMsg(''); }} placeholder="e.g. G-012" />
      </div>
      {msg && <p className="hint">{msg}</p>}
      {body}
    </div>
  );
}
