export function StatusBadge({ kind, label }) {
  return <span className={'badge badge-' + kind}>{label}</span>;
}
