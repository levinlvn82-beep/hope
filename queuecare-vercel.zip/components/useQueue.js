'use client';

import { useCallback, useEffect, useState } from 'react';

// Loads the queue and refreshes it every 3 seconds (live tracking).
export function useQueue(pin) {
  const [data, setData] = useState(null);
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    try {
      const res = await fetch('/api/queue', {
        cache: 'no-store',
        headers: pin ? { 'x-staff-pin': pin } : {},
      });
      const json = await res.json();
      if (!res.ok || !json.ok) throw new Error(json.error || 'Could not load data');
      setData(json);
      setError('');
    } catch (e) {
      setError(e.message || 'Network error');
    }
  }, [pin]);

  useEffect(() => {
    load();
    const id = setInterval(() => {
      if (!document.hidden) load();
    }, 3000);
    return () => clearInterval(id);
  }, [load]);

  return { data, error, refresh: load };
}

export async function postAction(body, pin) {
  const res = await fetch('/api/queue', {
    method: 'POST',
    cache: 'no-store',
    headers: { 'Content-Type': 'application/json', ...(pin ? { 'x-staff-pin': pin } : {}) },
    body: JSON.stringify(body),
  });
  let json = null;
  try {
    json = await res.json();
  } catch (e) {
    /* ignore */
  }
  if (!res.ok || !json || !json.ok) throw new Error((json && json.error) || 'Request failed');
  return json;
}
